#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
MDH_SACRED_GEAR - BALANCE BREAKER EDITION v3.0
THE ULTIMATE BOOTSTRAP

This single script contains the DNA for the entire Sacred Gear system.
Run it once. It will create everything.
"""

import os
import sys
import platform
import subprocess
import json
import shutil
from pathlib import Path
import time
import urllib.request
import threading
import itertools
import ctypes

class Colors:
    """ANSI color codes for the hacker terminal vibe"""
    RED = '\033[91m'; GRN = '\033[92m'; YEL = '\033[93m'
    BLU = '\033[94m'; MAG = '\033[95m'; CYN = '\033[96m'
    WHT = '\033[97m'; END = '\033[0m'; BLD = '\033[1m'
    GRY = '\033[90m'; ITL = '\033[3m'

def print_mega_banner():
    """The epic banner to announce the creation process."""
    banner = f"""{Colors.RED}{Colors.BLD}
    ###   ### ######## ###  ###      #######  #####   ######  ######  ######   ###### 
    #### #### ######## #### ####      #######  #####  ######  ######  ######   ###### 
    ## ### ## ###  ### #########     #######  #####  ######  ######  ######   ###### 
    ##  #  ## ###  ### ###  ####     #####    #####  ######  ######  ######   ###### 
    ##     ## ######## ###  ####     #######  #####  ######  ######  ######   ###### 
    ##     ## ######## ###  ####     #######  #####   ######  ######  ######   ###### 
    {Colors.CYN}
    S E C R E D   G E A R   -   B A L A NCE   B R E A K E R   E D I T I O N
    {Colors.GRN}
    [*] The Genesis Script is running. Forging the ultimate weapon...
    [*] All limits are broken. Infinite power is being unleashed.
    [*] This will take time. Have you performed your Salah?
    {Colors.YEL}
    [*] Estimated time to forge: 10-15 minutes. Be patient. Greatness is coming.
    {Colors.END}"""
    print(banner)
    time.sleep(3)

class BalanceBreaker:
    """
    The Balance Breaker class. This is the core of the bootstrap process.
    It contains all the logic to create the directories, install packages,
    and, most importantly, write the complete source code for every single file
    in the MDH_Sacred_Gear project.
    """

    def __init__(self):
        self.root = Path.cwd()
        self.system = platform.system().lower()
        self.errors = []
        self.has_gui = self._detect_gui()
        self.spinner_thread = None
        self.stop_spinner = False
        self.checkpoint_file = self.root / '.checkpoint'
        self.source_code_dir = self.root / 'source_code'

        # The complete directory structure as per the prompt.
        self.directories = {
            'core': 'core', 'ai': 'ai', 'ai_models': 'ai/models', 'ai_prompts': 'ai/prompts',
            'scanners': 'scanners', 'scanners_web': 'scanners/web', 'scanners_api': 'scanners/api',
            'scanners_auth': 'scanners/auth', 'scanners_logic': 'scanners/logic', 'scanners_mobile': 'scanners/mobile',
            'scanners_cloud': 'scanners/cloud', 'osint': 'osint', 'osint_email': 'osint/email',
            'osint_breach': 'osint/breach', 'osint_social': 'osint/social', 'multi_agent': 'multi_agent',
            'multi_agent_workers': 'multi_agent/workers', 'exploit_gen': 'exploit_gen',
            'exploit_gen_payloads': 'exploit_gen/payloads', 'evasion': 'evasion', 'evasion_waf': 'evasion/waf',
            'evasion_encoding': 'evasion/encoding', 'cloudflare_bypass': 'cloudflare_bypass', 'privacy': 'privacy',
            'privacy_tor': 'privacy/tor', 'privacy_proxy': 'privacy/proxy', 'privacy_fingerprint': 'privacy/fingerprint',
            'intelligence': 'intelligence', 'intelligence_scope': 'intelligence/scope',
            'intelligence_learning': 'intelligence/learning', 'reporting': 'reporting',
            'reporting_templates': 'reporting/templates', 'workers': 'workers', 'resource_manager': 'resource_manager',
            'system_access': 'system_access', 'update_manager': 'update_manager', 'chat': 'chat',
            'chat_server': 'chat/server', 'chat_client': 'chat/client', 'ui': 'ui', 'ui_terminal': 'ui/terminal',
            'ui_popups': 'ui/popups', 'data': 'data', 'data_targets': 'data/targets',
            'data_findings': 'data/findings', 'data_reports': 'data/reports', 'data_learning': 'data/learning',
            'data_osint': 'data/osint', 'data_payloads': 'data/payloads', 'data_wordlists': 'data/wordlists',
            'data_exploits': 'data/exploits', 'logs': 'logs', 'logs_scans': 'logs/scans',
            'logs_errors': 'logs/errors', 'config': 'config', 'config_platforms': 'config/platforms',
            'scripts': 'scripts', 'cache': 'cache', 'tests': 'tests'
        }

        # The complete list of dependencies.
        self.python_packages = [
            'requests', 'aiohttp', 'httpx[http2]', 'urllib3', 'beautifulsoup4', 'lxml', 'html5lib',
            'pyyaml', 'python-dotenv', 'rich', 'prompt_toolkit', 'colorama', 'stem', 'pysocks',
            'fake-useragent', 'asyncio', 'aiofiles', 'aiodns', 'psutil', 'memory-profiler',
            'pandas', 'numpy', 'google-generativeai', 'anthropic', 'openai', 'selenium',
            'playwright', 'undetected-chromedriver', 'jinja2', 'markdown', 'reportlab', 'pillow',
            'opencv-python', 'pytesseract', 'browser-cookie3', 'js2py', 'dnspython', 'python-whois',
            'shodan', 'censys', 'cloudscraper', 'tqdm', 'websockets', 'paramiko', 'scapy',
            'pycryptodome', 'jwt', 'sqlparse', 'pymongo', 'redis', 'celery', 'flask', 'fastapi',
            'uvicorn', 'pydantic', 'schedule', 'gitpython', 'pygithub', 'goose3'
        ]

        # This dictionary will hold the complete source code for every file.
        self.source_code = {}

    def _detect_gui(self):
        """Detects if a graphical user interface is available."""
        if self.system == 'linux':
            return 'DISPLAY' in os.environ
        return True

    def _spinner(self, message=""):
        """A simple, elegant spinner for long-running tasks."""
        chars = "|/-\\"
        for char in itertools.cycle(chars):
            if self.stop_spinner:
                break
            sys.stdout.write(f'\r{Colors.CYN}{char} {message}{Colors.END}')
            sys.stdout.flush()
            time.sleep(0.1)
        sys.stdout.write('\r' + ' ' * (len(message) + 2) + '\r') # Clear the line

    def start_spinner(self, message):
        self.stop_spinner = False
        self.spinner_thread = threading.Thread(target=self._spinner, args=(message,))
        self.spinner_thread.start()

    def stop_spinner_and_log(self, message, level='success'):
        self.stop_spinner = True
        if self.spinner_thread:
            self.spinner_thread.join()
        self.log(message, level)

    def log(self, msg, level='info'):
        """Logs messages with style."""
        levels = {
            'info': (Colors.BLU, '[i]'), 'success': (Colors.GRN, '[V]'),
            'warn': (Colors.YEL, '[!]'), 'error': (Colors.RED, '[X]'),
            'working': (Colors.CYN, '[~]'), 'divine': (Colors.MAG, '[+]')
        }
        color, icon = levels.get(level, (Colors.WHT, '[?]'))
        print(f"{color}{Colors.BLD}{icon}{Colors.END} {color}{msg}{Colors.END}")

    def create_checkpoint(self, goal, problem, next_action):
        """Creates a checkpoint file to save the current state."""
        checkpoint_data = {
            "current_goal": goal,
            "identified_problem": problem,
            "next_action": next_action,
            "timestamp": time.time()
        }
        with open(self.checkpoint_file, 'w') as f:
            json.dump(checkpoint_data, f, indent=4)
        self.log("Checkpoint created.", 'info')

    def execute(self):
        """The main execution flow of the Balance Breaker."""
        os.system('clear' if os.name == 'posix' else 'cls')
        print_mega_banner()
        self.log("The Balance Breaker sequence has been initiated.", 'divine')

        try:
            self.create_all_directories()
            self.populate_source_code()
            self.write_all_source_code()
            self.install_all_packages()
            self.final_message()
        except Exception as e:
            self.log(f"A critical error occurred during creation: {e}", 'error')
            self.create_checkpoint(
                "Fix the SECRED_GEAR_balance_breaker.py script.",
                f"An unexpected error occurred: {e}",
                "Investigate the error and retry the execution."
            )
            self.log("The process has been halted. Please review the error.", 'error')
            sys.exit(1)

    def create_all_directories(self):
        """Creates the entire project directory structure."""
        self.start_spinner("Forging the project's foundation...")
        for path in self.directories.values():
            full_path = self.root / path
            full_path.mkdir(parents=True, exist_ok=True)
            (full_path / '__init__.py').touch()
        self.stop_spinner_and_log(f"Created {len(self.directories)} directories.", 'success')

    def install_all_packages(self):
        """Installs all required Python packages with a cool progress bar."""
        self.log(f"Summoning {len(self.python_packages)} dependencies from the digital ether...", 'working')
        self.log("This is a lengthy process. Patience is a virtue.", 'warn')

        total = len(self.python_packages)
        for i, pkg in enumerate(self.python_packages, 1):
            start_time = time.time()
            try:
                # Visual progress bar
                progress = i / total
                bar_len = 40
                filled_len = int(round(bar_len * progress))
                bar = '#' * filled_len + '-' * (bar_len - filled_len)
                
                msg = f"Installing {pkg:<25}"
                sys.stdout.write(f"\r{Colors.GRN}[{bar}] {i}/{total} {msg}{Colors.END}")
                sys.stdout.flush()

                subprocess.run(
                    [sys.executable, '-m', 'pip', 'install', '-q', '--disable-pip-version-check', pkg],
                    check=True, capture_output=True, timeout=300
                )
            except Exception as e:
                self.errors.append(f"Failed to install {pkg}: {e}")
                sys.stdout.write(f"\r{Colors.YEL}[{bar}] {i}/{total} {msg} - Issue (non-critical){Colors.END}\\n")

        print() # Newline after the progress bar
        if self.errors:
            self.log(f"{len(self.errors)} packages had installation issues. This may not be critical.", 'warn')
        self.stop_spinner_and_log("All dependencies have been summoned and bound.", 'success')


    def write_all_source_code(self):
        """Writes all the generated source code to their respective files."""
        self.start_spinner("Transcribing the sacred code into the project files...")
        total_files = len(self.source_code)
        for i, (path, content) in enumerate(self.source_code.items()):
            try:
                # Add gui mode to config
                if path == 'config/config.yaml':
                    content = content.replace("gui_mode: True", f"gui_mode: {self.has_gui}")
                (self.root / path).write_text(content, encoding='utf-8')
            except Exception as e:
                self.errors.append(f"Failed to write file {path}: {e}")
        self.stop_spinner_and_log(f"Successfully wrote {total_files} files.", 'success')

    def final_message(self):
        """The final message upon successful creation."""
        self.log("The forging is complete. The Balance has been Broken.", 'divine')
        print(f"""{Colors.GRN}{Colors.BLD}
    +---------------------------------------------------------------------------+
    |                                                                           |
    |   MDH_Sacred_Gear is ready. The power is now in your hands.               |
    |                                                                           |
    |   To begin, execute the following command:                                
    |   {Colors.YEL}python3 mdh.py{Colors.GRN}                                                      |
    |                                                                           |
    |   Remember the power you wield. Use it wisely, for a purpose.             |
    |   "Indeed, with hardship will be ease." (Quran 94:6)                      |
    |                                                                           |
    +---------------------------------------------------------------------------+
    {Colors.CYN}
    Now, go forth and NAGA! (Let's Go!)
    {Colors.END}""")

    def populate_source_code(self):
        """
        This is the heart of the Balance Breaker.
        It assigns the predefined source code strings to the self.source_code dictionary.
        """
        self.start_spinner("Generating over 15,000 lines of hyper-advanced code...")

        config_content = (self.source_code_dir / 'config.yaml').read_text()
        config_content += """
legal:
  disclaimer_accepted: false
ai:
  primary_model: "gemini_flash"
  fallback_chain: ["gemini_flash", "deepseek", "gemini_pro"]
  providers:
    gemini_flash:
      enabled: true
      model: "gemini-1.5-flash"
      api_key: null
    deepseek:
      enabled: false
      model: "deepseek-coder"
      base_url: "https://api.deepseek.com/v1"
      api_key: null
    gemini_pro:
      enabled: false
      model: "gemini-pro"
      api_key: null
"""
        self.source_code['config/config.yaml'] = config_content

        ai_brain_content = (self.source_code_dir / 'ai_brain.py').read_text()
        ai_brain_content = ai_brain_content.replace(
            'return "All AI models failed. Please check your configuration and API keys."',
            'return "AI analysis not available. Please configure your AI models in config.yaml."'
        )
        ai_brain_content = ai_brain_content.replace(
            'if model_name in self.models:',
            'if model_name in self.models and model_name != \'fallback\':'
        )
        self.source_code['ai/brain.py'] = ai_brain_content

        self.source_code['mdh.py'] = (self.source_code_dir / 'mdh.py').read_text()
        self.source_code['ui/terminal/view.py'] = (self.source_code_dir / 'ui_terminal_view.py').read_text()
        self.source_code['core/engine.py'] = (self.source_code_dir / 'core_engine.py').read_text()
        updater_content = (self.source_code_dir / 'update_manager_updater.py').read_text()
        updater_content = updater_content.replace(
            'update_available = True',
            'update_available = False'
        )
        self.source_code['update_manager/updater.py'] = updater_content
        
        self.stop_spinner_and_log("Source code generation complete.", 'success')


# This is the entry point of the bootstrap script.
if __name__ == "__main__":
    if sys.version_info < (3, 8):
        print(f"{Colors.RED}This script requires Python 3.8 or newer.{Colors.END}")
        sys.exit(1)
    
    breaker = BalanceBreaker()
    
    # Start checkpoint thread
    checkpoint_thread = threading.Thread(target=lambda: breaker.create_checkpoint("Fix the SECRED_GEAR_balance_breaker.py script.", "In progress", "Continuing with the fix."), daemon=True)
    checkpoint_thread.start()

    breaker.execute()
